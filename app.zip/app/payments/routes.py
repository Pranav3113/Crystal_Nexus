from decimal import Decimal
from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from sqlalchemy import func

from app import db
from app.models import Quote, PaymentCollection

payments_bp = Blueprint("payments", __name__, url_prefix="/payments")

def get_current_collected(quote_id: int, exclude_payment_id: int = None):
    q = (db.session.query(func.coalesce(func.sum(PaymentCollection.amount), 0))
         .filter(PaymentCollection.quote_id == quote_id)
         .filter(PaymentCollection.status != "Rejected"))
    if exclude_payment_id:
        q = q.filter(PaymentCollection.id != exclude_payment_id)
    return q.scalar()


def validate_collection(quote: Quote, new_amount, exclude_payment_id: int = None):
    current = Decimal(str(get_current_collected(quote.id, exclude_payment_id=exclude_payment_id)))
    new_amount = Decimal(str(new_amount))

    if new_amount <= 0:
        raise ValueError("Amount must be greater than 0.")

    if current + new_amount > Decimal(str(quote.total_amount)):
        remaining = Decimal(str(quote.total_amount)) - current
        raise ValueError(f"Collection exceeds quote amount. Remaining: {remaining}")

def ensure_lead_owner_or_admin(quote: Quote):
    # Quote -> Opportunity -> owner_id
    opp_owner_id = quote.opportunity.owner_id if quote.opportunity else None

    # RBAC: if you prefer permission-based, replace with has_perm checks
    if opp_owner_id != current_user.id and not current_user.has_perm("payments.admin"):
        abort(403)


def ensure_finance_or_admin():
    if not (current_user.has_perm("payments.verify") or current_user.has_perm("payments.admin")):
        abort(403)


@payments_bp.route("/quote/<int:quote_id>", methods=["GET", "POST"])
@login_required
def quote_payments(quote_id):
    quote = Quote.query.get_or_404(quote_id)
    ensure_lead_owner_or_admin(quote)
    

    if request.method == "POST":
        if not getattr(quote, "proposal_confirmed_at", None):
            flash("Payments can be updated only after Proposal is Confirmed.", "danger")
            return redirect(url_for("payments.quote_payments", quote_id=quote.id))

        try:
            payment_date = datetime.strptime(request.form["payment_date"], "%Y-%m-%d").date()
            amount = request.form["amount"]
            transfer_type = request.form["transfer_type"]
            reference = request.form.get("reference", "").strip() or None

            validate_collection(quote, amount)

            pc = PaymentCollection(
                quote_id=quote.id,
                lead_id=quote.opportunity.lead_id if quote.opportunity else None,
                payment_date=payment_date,
                amount=amount,
                transfer_type=transfer_type,
                reference=reference,
                status="Pending",
                created_by_id=current_user.id
            )
            db.session.add(pc)
            db.session.commit()
            flash("Payment update added and sent for finance verification.", "success")
        except ValueError as e:
            db.session.rollback()
            flash(str(e), "danger")
        except Exception:
            db.session.rollback()
            flash("Failed to add payment update.", "danger")

        return redirect(url_for("payments.quote_payments", quote_id=quote.id))

    payments = (PaymentCollection.query
                .filter_by(quote_id=quote.id)
                .order_by(PaymentCollection.payment_date.desc(), PaymentCollection.created_at.desc())
                .all())

    collected = quote.collected_amount()
    remaining = quote.remaining_amount()

    return render_template("payments/quote_payments.html",
                           quote=quote, payments=payments,
                           collected=collected, remaining=remaining)


@payments_bp.route("/finance/queue", methods=["GET"])
@login_required
def finance_payment_queue():
    ensure_finance_or_admin()
    pending = (PaymentCollection.query
               .filter_by(status="Pending")
               .order_by(PaymentCollection.created_at.asc())
               .all())
    return render_template("payments/finance_payment_queue.html", pending=pending)


@payments_bp.route("/finance/payment/<int:payment_id>/action", methods=["POST"])
@login_required
def finance_payment_action(payment_id):
    ensure_finance_or_admin()

    pc = PaymentCollection.query.get_or_404(payment_id)
    action = request.form.get("action")  # verify / reject
    remarks = request.form.get("finance_remarks", "").strip() or None

    try:
        if action == "verify":
            quote = Quote.query.get_or_404(pc.quote_id)

            # ✅ IMPORTANT: re-check cap at verify time
            validate_collection(quote, pc.amount, exclude_payment_id=pc.id)

            pc.status = "Verified"
            pc.verified_by_id = current_user.id
            pc.verified_at = datetime.utcnow()
            pc.finance_remarks = remarks

        elif action == "reject":
            pc.status = "Rejected"
            pc.verified_by_id = current_user.id
            pc.verified_at = datetime.utcnow()
            pc.finance_remarks = remarks

        else:
            flash("Invalid action.", "danger")
            return redirect(url_for("payments.finance_payment_queue"))

        db.session.commit()
        flash(f"Payment {pc.status.lower()} successfully.", "success")

    except ValueError as e:
        db.session.rollback()
        flash(str(e), "danger")
    except Exception:
        db.session.rollback()
        flash("Action failed.", "danger")

    return redirect(url_for("payments.finance_payment_queue"))