from flask import Flask, app, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager,current_user
from config import Config



db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    migrate.init_app(app, db)

    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    # Blueprints
    from .auth.routes import auth_bp
    from .admin.routes import admin_bp
    from .leads.routes import leads_bp
    from .pipeline.routes import pipeline_bp
    from .quotes.routes import quotes_bp
    from .admin.user_master import user_master_bp
    from .admin.designations import designations_bp
    from .admin.rbac_master import rbac_bp
    from .clients.routes import clients_bp
    from .cli import register_cli
    from app.payments.routes import payments_bp
    from .admin.industries import industries_bp
    from app.company_master.routes import company_bp
    app.register_blueprint(company_bp)
    app.register_blueprint(industries_bp, url_prefix="/admin")
    app.register_blueprint(payments_bp)
    register_cli(app)
    app.register_blueprint(clients_bp, url_prefix="/clients")
    app.register_blueprint(rbac_bp, url_prefix="/admin")
    app.register_blueprint(designations_bp, url_prefix="/admin")
    app.register_blueprint(user_master_bp, url_prefix="/admin")
    app.register_blueprint(quotes_bp, url_prefix="/quotes")
    app.register_blueprint(pipeline_bp, url_prefix="/pipeline")
    app.register_blueprint(leads_bp, url_prefix="/leads")
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")
    

    # Home
    @app.route("/")
    def home():
        if current_user.is_authenticated:
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("auth.login"))

    return app