from sqlalchemy import text
from . import db
from .models import (
    User, Role, Permission,
    LeadStatus, LeadSource,
    PipelineStage, QuoteStatus, ActivityType,
    ApprovalRule, ApprovalRuleStep, Industry,
)

def seed_all():
    # ---- Role ----
    admin_role = Role.query.filter_by(name="Admin").first() or Role(name="Admin")
    db.session.add(admin_role)
    db.session.flush()

    perm_codes = [
        "admin.dashboard.view",

        # leads
        "leads.view", "leads.create", "leads.edit", "leads.assign","leads.assign_any","leads.view_all",
        "masters.manage",
        "activities.view", "activities.create",
        "admin.audit.view",
        "pipeline.view", "pipeline.create", "pipeline.edit", "pipeline.move", "pipeline.manage_stages",
        "quotes.view", "quotes.create", "quotes.edit", "quotes.request_approval", "quotes.approve", "quotes.send",
        "approval_rules.manage",
        "users.manage", "designations.manage",
        "roles.manage", "permissions.manage",
        "clients.manage",
        "payments.add",
        "payments.admin","payments.verify","payments.view",
        "industries.manage",
        "quotes.proposals_sent.view",
        "company.manage","company.view",  
    ]

    for code in perm_codes:
        if not Permission.query.filter_by(code=code).first():
            db.session.add(Permission(code=code, description=code))

    # ---- Masters ----
    defaults_statuses = [
        ("New", "primary", 1),
        ("Contacted", "info", 2),
        ("Qualified", "success", 3),
        ("Lost", "secondary", 90),
    ]
    for name, color, order in defaults_statuses:
        if not LeadStatus.query.filter_by(name=name).first():
            db.session.add(LeadStatus(name=name, color=color, sort_order=order, is_active=True))

    defaults_sources = [
        ("Website", 1),
        ("Referral", 2),
        ("Cold Call", 3),
        ("Walk-in", 4),
    ]
    for name, order in defaults_sources:
        if not LeadSource.query.filter_by(name=name).first():
            db.session.add(LeadSource(name=name, sort_order=order, is_active=True))

    

    default_industries = [
        ("Information Technology", 1),
        ("Software / SaaS", 2),
        ("Manufacturing", 3),
        ("Healthcare", 4),
        ("Pharmaceuticals", 5),
        ("Education", 6),
        ("Retail", 7),
        ("E-Commerce", 8),
        ("Real Estate", 9),
        ("Finance", 10),
        ("Banking", 11),
        ("Insurance", 12),
        ("Logistics", 13),
        ("Construction", 14),
        ("Hospitality", 15),
        ("Media & Entertainment", 16),
        ("Telecom", 17),
        ("Automobile", 18),
        ("FMCG", 19),
        ("Government", 20),
    ]

    for name, order in default_industries:
        if not Industry.query.filter_by(name=name).first():
            db.session.add(Industry(name=name, sort_order=order, is_active=True))

    default_activity_types = [
        ("Call", "telephone", 1),
        ("Email", "envelope", 2),
        ("Meeting", "calendar-event", 3),
        ("WhatsApp", "chat-dots", 4),
        ("Site Visit", "geo-alt", 5),
    ]
    for name, icon, order in default_activity_types:
        if not ActivityType.query.filter_by(name=name).first():
            db.session.add(ActivityType(name=name, icon=icon, sort_order=order, is_active=True))

    default_stages = [
        ("Prospect", "secondary", 10, 1),
        ("Qualified", "info", 30, 2),
        ("Proposal", "primary", 50, 3),
        ("Negotiation", "warning", 70, 4),
        ("Won", "success", 100, 90),
        ("Lost", "dark", 0, 99),
    ]
    for name, color, prob, order in default_stages:
        if not PipelineStage.query.filter_by(name=name).first():
            db.session.add(PipelineStage(name=name, color=color, probability=prob, sort_order=order, is_active=True))

    default_quote_statuses = [
        ("Draft", 1),
        ("Pending Approval", 2),
        ("Approved", 3),
        ("Selected", 4),
        ("Rejected", 5),
        ("Sent", 6),
    ]
    for name, order in default_quote_statuses:
        if not QuoteStatus.query.filter_by(name=name).first():
            db.session.add(QuoteStatus(name=name, sort_order=order, is_active=True))

    # ---- Approval Rules + Steps ----
    default_rules = [
        ("Default Approval (>= 1)", 1, None, "Admin", 1),
    ]
    for r_name, min_amt, max_amt, approver_role, order in default_rules:
        rule = ApprovalRule.query.filter_by(name=r_name).first()
        if not rule:
            rule = ApprovalRule(
                name=r_name,
                min_amount=min_amt,
                max_amount=max_amt,
                approver_role=approver_role,
                sort_order=order,
                is_active=True
            )
            db.session.add(rule)
            db.session.flush()

        if rule.steps.count() == 0:
            db.session.add(ApprovalRuleStep(
                rule_id=rule.id,
                step_order=1,
                approver_role=approver_role,
                approver_user_id=None,
                is_active=True
            ))

    db.session.commit()

    # Make Admin have all permissions
    admin_role.permissions = Permission.query.all()
    db.session.commit()

    # ---- Admin User ----
    u = User.query.filter_by(email="admin@crystalnexus.local").first()
    if not u:
        u = User(email="admin@crystalnexus.local", name="System Admin", role=admin_role, auth_provider="LOCAL", is_active=True)
        u.set_password("Admin@1234")
        db.session.add(u)
        db.session.commit()


def wipe_all_tables():
    """
    Wipes ALL tables in current DB (UAT helper).
    Works well for MySQL.
    """
    conn = db.engine.connect()
    trans = conn.begin()
    try:
        conn.execute(text("SET FOREIGN_KEY_CHECKS=0;"))

        # delete all rows from every table (metadata order)
        for table in reversed(db.metadata.sorted_tables):
            conn.execute(text(f"TRUNCATE TABLE `{table.name}`;"))

        conn.execute(text("SET FOREIGN_KEY_CHECKS=1;"))
        trans.commit()
    except Exception:
        trans.rollback()
        raise
    finally:
        conn.close()


def register_cli(app):
    @app.cli.command("seed")
    def seed_cmd():
        """Seed initial masters/admin"""
        seed_all()
        print("✅ Seed completed")

    @app.cli.command("reset-db")
    def reset_db_cmd():
        """Wipe DB + re-run seed (UAT helper)"""
        wipe_all_tables()
        seed_all()
        print("✅ DB wiped + reseeded")